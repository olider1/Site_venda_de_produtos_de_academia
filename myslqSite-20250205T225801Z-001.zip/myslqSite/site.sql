create database site;

use site;

create table produto(
IDproduto int primary key not null auto_increment,
nome varchar(100) not null check (length(nome)>=10),
descricao varchar (200) not null,
quantidade numeric (5) not null,
preco decimal (8,2) not null
);
select * from produto;

insert into produto values(null,"guilherme emanuel","foda",4,450099);

create table cliente(
IDcliente int primary key not null auto_increment,
nome varchar (100) not null check(length(nome)>=10) unique,
email varchar (150) not null,
senha varchar (15) not null check(length(senha)>=8),
telefone numeric (12) not null check(length(telefone)>=11)
);

select * from cliente;

insert into cliente values(null,"guilherme emanuel","guilhermeemanuel",0307200555,61981325653);

create table compra(
IDcompra int primary key not null auto_increment,
id_produto int,
id_cliente int,

foreign key (id_produto) references produto(IDproduto),
foreign key (id_cliente) references cliente(IDcliente)
);

select * from compra;

insert into compra values (null,1,1);

create table servico(
IDservico int primary key not null auto_increment,
nome varchar(100) not null check(length(nome)>=10),
descricao varchar(200) not null,
preco decimal (8,2) not null
);

select * from servico;

insert into servico values(null,"servico pika vale a pena","muito pika relaxa",499880);

create table agendamentos(
IDagendamentos int primary key not null auto_increment,
id_servico int,
id_cliente int,
datas date,

foreign key (id_servico) references servico(IDservico),
foreign key (id_cliente) references cliente(IDcliente)

);

select * from agendamentos;

insert into agendamentos values(null,1,1,"2025-07-03");

