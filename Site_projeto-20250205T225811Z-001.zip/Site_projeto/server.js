const express = require('express');
const mysql = require('mysql2');
const cors = require('cors'); // Importando o pacote CORS
const app = express();

app.use(cors()); // Usando o CORS no servidor (permite requisições de qualquer origem)
app.use(express.json());

// Criando a conexão com o banco de dados
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '2mic50@NOMAD', // Substitua se necessário
  database: 'site' // Nome do seu banco de dados
});

db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
  } else {
    console.log('Conectado ao banco de dados');
  }
});

// Rota POST para o cadastro
app.post('/register', (req, res) => {
  console.log('Requisição de cadastro recebida');
  const { name, email, password, phone } = req.body;

  // Verificar se todos os campos foram preenchidos
  if (!name || !email || !password || !phone) {
    return res.status(400).json({ message: 'Todos os campos são obrigatórios.' });
  }

  // Verificar se o email já está registrado
  db.query('SELECT * FROM cliente WHERE email = ?', [email], (err, result) => {
    if (err) {
      console.error('Erro ao verificar email:', err);
      return res.status(500).json({ message: 'Erro ao verificar email: ' + err.message });
    }

    console.log('Resultado da consulta para verificar email:', result);

    if (result.length > 0) {
      return res.status(400).json({ message: 'Email já registrado.' });
    }

    // Inserir o novo usuário na tabela
    const query = 'INSERT INTO cliente (nome, email, senha, telefone) VALUES (?, ?, ?, ?)';
    db.query(query, [name, email, password, phone], (err, result) => {
      if (err) {
        console.error('Erro ao cadastrar usuário:', err);
        return res.status(500).json({ message: 'Erro ao cadastrar usuário: ' + err.message });
      }

      console.log('Usuário inserido com sucesso:', result);
      res.status(200).json({ message: 'Cadastro realizado com sucesso!' });
    });
  });
});

// Rota para login
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    // Verificar se o email e senha existem no banco
    db.query('SELECT * FROM cliente WHERE email = ? AND senha = ?', [email, password], (err, results) => {
        if (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).json({ success: false, message: 'Erro no servidor.' });
        }

        if (results.length > 0) {
            // Login bem-sucedido
            res.json({ success: true, message: 'Login realizado com sucesso!' });
        } else {
            // Falha no login
            res.json({ success: false, message: 'Falha no login. Verifique suas credenciais.' });
        }
    });
});

// Definindo a porta para o servidor
const port = 3001;
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
