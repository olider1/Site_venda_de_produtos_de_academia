document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Impede o envio normal do formulário

    // Captura os dados do formulário
    const username = event.target.username.value;
    const password = event.target.password.value;

    // Envia os dados para o backend via POST
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Login realizado com sucesso!') {
            alert('Login realizado com sucesso!');
            // Redireciona para a página inicial ou dashboard
            window.location.href = '/';
        } else {
            alert('Credenciais inválidas. Tente novamente.');
        }
    })
    .catch(error => {
        console.error('Erro no login:', error);
        alert('Ocorreu um erro. Tente novamente mais tarde.');
    });
});