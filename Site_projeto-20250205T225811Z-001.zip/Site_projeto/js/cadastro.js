document.addEventListener('DOMContentLoaded', function() {
    const cadastroForm = document.getElementById('cadastroForm');

    // Verifica se o formulário foi encontrado
    if (cadastroForm) {
        cadastroForm.addEventListener('submit', function (event) {
            event.preventDefault(); // Impede o envio do formulário para usar o Ajax

            // Coleta os dados do formulário
            const email = event.target.email.value.trim();
            const password = event.target.password.value.trim();

            // Validação simples: Verificar se os campos não estão vazios
            if (!email || !password) {
                alert('Por favor, preencha todos os campos.');
                return;
            }

            // Monta o corpo da requisição
            const userData = {
                email: email,
                password: password
            };

            // Log dos dados que estão sendo enviados
            console.log('Dados enviados para o backend:', userData);

            // Envia a requisição para a rota de cadastro
            fetch('http://localhost:3001/cadastro', {  // Adicione o domínio/porta se necessário
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData)
            })
            
            .then(response => {
                // Verifica se a resposta foi bem-sucedida
                if (!response.ok) {
                    throw new Error('Erro na resposta do servidor. Status: ' + response.status);
                }
                return response.json(); // Tenta converter a resposta em JSON
            })
            .then(data => {
                // Log da resposta do servidor
                console.log('Resposta do servidor:', data);

                // Se o cadastro for bem-sucedido
                if (data.message === 'Cadastro realizado com sucesso!') {
                    alert('Cadastro realizado com sucesso!');
                    window.location.href = '/login'; // Redireciona para a página de login
                } else {
                    alert('Erro no cadastro: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Erro no envio da requisição:', error);
                alert('Ocorreu um erro ao tentar cadastrar. Tente novamente mais tarde.');
            });
        });
    } else {
        console.error('Elemento com ID "cadastroForm" não encontrado.');
    }
});
